Huiyi Zhang 3032690221

Instructions on how to reproduce results:
Run all cells in the jupyter notebook "cs189hw4code.ipynb," which should be put in the same directory as the "data" folder that contains all the data we used. 
The random seed is set to be 140. 

Please ignore all code that was commented out as they are just for my reference and no longer needed.