Huiyi Zhang 3032690221

Instructions on how to reproduce results:
Run all cells in the jupyter notebook.